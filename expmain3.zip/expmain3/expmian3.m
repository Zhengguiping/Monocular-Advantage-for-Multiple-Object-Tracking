%% ����ʵ��1��
clear;
clc;
%%    ʵ��ǰ�ռ�������Ϣ
rng('shuffle');%%����������ӵ�
Screen('Preference','SkipSyncTests', 1);%ǿ������ͬ��
subject = input('Enter Subject Number:    ');%���뱻����Ϣ
try
    %%  ��Ļ����
    inch = 24;%��ʾ����С
    vdist =57;%�۾�������Ļ�ľ���
    scr=max(Screen('Screens'));
    [sw,sh]=Screen('WindowSize',scr); %%��Ļ����
    [wptr,wrect]=Screen('OpenWindow',scr,[128 128 128],[0 0 sw sh]); %%��ȡ��Ļָ��
     load MyGamma_Table
    Screen('LoadNormalizedGammaTable', wptr, gammaTable*[1 1 1]);
    [x,y] = WindowCenter(wptr);
    xCenter_left = x/2;%���1����������x
    xCenter_right = x*3/2;%�ұ�2����������x
    yCenter = y;
    ShowCursor('Arrow',wptr); %%ʼ�ճ��ּ�ͷ
    %%    ��������
    degree_diameter=1.2;%С��ֱ��
    diameter = deg2pix(degree_diameter,inch,sw,vdist);
    duration=5;%׷��ʱ��5s
    angles=[5:35:75,95:35:165,185:35:255,275:35:345];%�Ƕ�
    penwidth = 2;  % ��Ĵ�ϸ
    griddpenwidth=penwidth ; %%�����ߵĴ�ϸ
    mark_large = 8;%�Ŵ���Ŀ��Ķ���
    mark_penwidth = 6;%���Ŀ��Ĵ�ϸ
    cyd = 5;%%ʮ�ּܵİ����
    cyl = 20;%%ʮ�ּܵİ����
    degree_sc = 0.1;   %%%С����С���ӽ�
    sc = deg2pix(degree_sc,inch,sw,vdist);
    degree_exRect = 15.44;%%���15.44��
    exRect = deg2pix(degree_exRect ,inch,sw,vdist);
    degree_baseRect1 = 15;%%��Ĵ�С���ӽ�(�ڿ�)
    baseRect = deg2pix(degree_baseRect1 ,inch,sw,vdist);
    gap = exRect-baseRect;  %����
    baseRect1 = [(sw-baseRect*2)/4,(sh-baseRect)/2,sw/4+baseRect/2,sh/2+baseRect/2];%1���С
    exRect1 = [baseRect1(1)-gap,baseRect1(2)-gap,baseRect1(3)+gap,baseRect1(4)+gap];%���������
    baseRect2 = OffsetRect(baseRect1,sw/2,0);%1��ƽ��sw/2�õ�2��
    exRect2 = OffsetRect(exRect1,sw/2,0);%�����ƽ��sw/2�õ������
    dimention1=baseRect1(3)-baseRect1(1);%1��ĳ��ȺͿ���
    dimention2=dimention1;
    collisionwithothers=zeros(1,12);%��ײ������¼��ò��û��Ҫ
    collisionwithborder=zeros(1,12);
    %%  ���ܴ�������
    %  ��߸���4������������
    check_left1 = [exRect1(1) exRect1(2) baseRect1(1) exRect1(4)];
    check_right1 = [baseRect1(3) exRect1(2) exRect1(3) exRect1(4)];
    check_up1 = [exRect1(1) exRect1(2) exRect1(3) baseRect1(2)];
    check_down1 = [exRect1(1) baseRect1(4) exRect1(3) exRect1(4)];
    %  �ֱ�ƽ�Ƶ��ұ�����
    check_left2 = OffsetRect(check_left1,sw/2,0);
    check_right2 = OffsetRect(check_right1,sw/2,0);
    check_up2 = OffsetRect(check_up1,sw/2,0);
    check_down2 = OffsetRect(check_down1,sw/2,0);
    % ÿ��С��������
    checknum = (exRect/gap+1)/2; %%
    check_sleft1 = zeros(4,checknum);
    check_sup1 = zeros(4,checknum);
    check_sright1 = zeros(4,checknum);
    check_sdown1 = zeros(4,checknum);
    %%
    for i=1:2:checknum-1
        for  j=2:2:checknum
            check_sleft1(:,i)= [exRect1(1) exRect1(2)+(i-1)*gap*2 baseRect1(1) exRect1(2)+i*gap*2];
            check_sup1(:,j) = [exRect1(1)+(j-1)*gap*2 exRect1(2) exRect1(1)+j*gap*2 baseRect1(2)];
            check_sright1 = OffsetRect(check_sleft1,baseRect+gap,0);
            check_sdown1  = OffsetRect(check_sup1,0,baseRect+gap);
            check_sleft2= OffsetRect(check_sleft1,sw/2,0);
            check_sup2 =  OffsetRect(check_sup1,sw/2,0);
            check_sright2 = OffsetRect(check_sright1,sw/2,0);
            check_sdown2  = OffsetRect(check_sdown1,sw/2,0);
        end
    end
    %%  �ϲ���
    rect = [baseRect1' baseRect2' exRect1' exRect2'];  %%������ο�
    blackcheck = [check_left1' check_right1' check_up1' check_down1' check_left2' check_right2' check_up2' check_down2'];
    whitecheck = horzcat(check_sleft1,check_sright1,check_sup1,check_sdown1,check_sleft2,check_sright2,check_sup2,check_sdown2);
    
    %%    �ڲ������ߵ�����
    cols1=floor(dimention1/diameter);
    rows1=floor(dimention2/diameter);
    xys1=zeros(2,cols1*2);
    xys2=zeros(2,rows1*2);
    xys3=zeros(2,cols1*2);
    xys4=zeros(2,rows1*2);
    for i=1:cols1
        xys1(1,2*i-1)=baseRect1(1);
        xys1(2,2*i-1)=(dimention1/cols1)*i+baseRect1(2);
        xys1(1,2*i)=baseRect1(3);
        xys1(2,2*i)=(dimention1/cols1)*i+baseRect1(2);
    end
    for i=1:rows1
        xys2(1,2*i-1)=(dimention1/rows1)*i+baseRect1(1);
        xys2(2,2*i-1)=baseRect1(2);
        xys2(1,2*i)=(dimention1/rows1)*i+baseRect1(1);
        xys2(2,2*i)=baseRect1(4);
    end
    for i=1:cols1
        xys3(1,2*i-1)=baseRect2(1);
        xys3(2,2*i-1)=(dimention1/cols1)*i+baseRect2(2);
        xys3(1,2*i)=baseRect2(3);
        xys3(2,2*i)=(dimention1/cols1)*i+baseRect2(2);
    end
    for i=1:rows1
        xys4(1,2*i-1)=(dimention1/rows1)*i+baseRect2(1);
        xys4(2,2*i-1)=baseRect2(2);
        xys4(1,2*i)=(dimention1/rows1)*i+baseRect2(1);
        xys4(2,2*i)=baseRect2(4);
    end
    % �ϲ�����
    xys = horzcat(xys1,xys2,xys3,xys4);
    %%   ���尴��
    KbName('UnifyKeyNames');
    quitKey=KbName('ESCAPE');
    spacebar=KbName('Space');
    %%   ��������
    Screen('TextSize', wptr, 50);
    Screen('TextFont', wptr, 'Times New Roman');
    %%   ��ɫ����
    white = [255 255 255];
    black= [0 0 0];
    red = [255 0 0];
    grey = [128 128 128];
    %%%  ��ɫ����
    color = ones(3,12);
    color1 = ones(3,4);
    color2 = ones(3,4);
    color3 = ones(3,4);
    
    %%  ʱ������
    t1=0.15;   %% ���л�/�л�flipʱ��
    %%    �����ο�ת���������,����������ĸ���
    cols=floor(dimention1/diameter)-2;  %%��
    rows=floor(dimention2/diameter)-2;   %%��
    left1=(sw/2-cols*diameter)/2;   %%1������С�������������
    top=(sh-rows*diameter)/2;  %%1������С�������ϱ�����
    grids=NaN*ones(floor((cols+1)/2)*floor((rows+1)/2),4);
    k=1;
    for i=1:3:cols    %%�������С��ļ��
        for j=1:3:rows
            grids1(k,:)=[left1+(i-1)*diameter,top+(j-1)*diameter,left1+i*diameter,top+j*diameter];
            k=k+1;
        end
    end
    totalgrids1=1:k-1;   %%����ǿ������ɵ�С����������
    %%  ������������
    fileName = BuildMatrix21(['S',num2str(subject)]);
    load(fileName);
    %% ������ֱ����ʮ�ּܣ���֤����
    up_rect = [xCenter_left-cyd,yCenter-cyl,xCenter_left+cyd,yCenter+cyl]; %%��1ʮ�ּ����²���
    left_rect = [xCenter_left-cyl,yCenter-cyd,xCenter_left+cyl,yCenter+cyd]; %%��1ʮ�ּ����Ҳ���
    down_rect=[xCenter_right-cyd,yCenter-cyl,xCenter_right+cyd,yCenter+cyl]; %%��2ʮ�ּ����²���
    right_rect=[xCenter_right-cyl,yCenter-cyd,xCenter_right+cyl,yCenter+cyd]; %%��2ʮ�ּ����Ҳ���
    cross = horzcat(up_rect',left_rect',down_rect',right_rect');
    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
    Screen('FrameRect', wptr, grey,rect, penwidth);
    Screen('FillRect', wptr, black,blackcheck, penwidth);
    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
    Screen('FillRect', wptr, black,cross, penwidth);%%����ʮ�ּ�
    Screen('Flip',wptr);
    %%  �������ж���
    while 1
        [clicks,x,y,whichbutton]=GetClicks;
        if clicks && whichbutton==1  %�����������ѭ��
            break;
        end
    end
    %%   ��ʼʵ�飬20��trail��Ϣһ��
    for trialIndex = 1:length(Matrix21)
        %         for trialIndex = 1:3
        %%  4��selected
        selected1=zeros(1,4);
        selected11=zeros(1,4);
        selected12=zeros(1,4);
        selected13=zeros(1,4);
        selected21=zeros(1,4);
        selected22=zeros(1,4);
        selected23=zeros(1,4);  %���������С����
        crtnumber1=0;
        crtnumber2=0;  %ÿ��ѭ����ʼ�����´�0��ʼ������ȷ׷��С�����
        %%  �����ڿ�1������ɲ��غϵ�12����
        randomdots1=Shuffle(totalgrids1);    %%����������ɵ��ܷ���
        for i=1:12   %%�������12����
            rect5(:,i)=grids1(randomdots1(i),:)';
            rect15(:,i)=InsetRect(rect5(:,i)',sc,sc);
        end
        %%  Ŀ�������������������������Ŀ��������������
                if  Matrix21(trialIndex,2)==1    %%%ˢ����Ϊ100hz��2����ͬ���ٶ�ֵ
                    degree_speed = 0.04;  %%�ٶ�1
                elseif  Matrix21(trialIndex,2)==2
                    degree_speed = 0.08;%%�ٶ�3
                end
        speed = deg2pix(degree_speed,inch,sw,vdist);   %%���ӽǶ���ת��Ϊ����
        for i=1:12     %%�������12����ͬ������˶��ٶȺ���ɫ
            angle(i)=angles(randi(length(angles)));
            speedxy(i,:)=[speed*cosd(angle(i)),speed*sind(angle(i))];
        end
        
        if  Matrix21(trialIndex,3)==1   %% Ŀ��������
            %%  С�������ɫ����
            x = randsample(0:12,12);
            for k = 1:12
                b = x(k);
                color(:,k) = [b b b];
            end
            for i=1:4
                color1(:,i) =  color(:,i);
                color2(:,i) =  color(:,i+4);
                color3(:,i) =  color(:,i+8);
            end
            %% ����С��1��8��С��4��Ŀ�꣬4�������2���ĸ�������
            for i=1:4
                rect1(:,i)=rect15(:,i);   %%rect1ǰ4��С��1��
                rect2(:,i)=rect15(:,i+4);  %%rect2�м�4��С��1��
                rect4(:,i)=rect15(:,i+8);
                rect3(:,i)=OffsetRect(rect4(:,i)',sw/2,0);%%rect3���4��С��2��
            end
            Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);%%��ɫ������
            Screen('FrameRect', wptr, grey,rect, penwidth); %�����
            Screen('FillRect', wptr, black,blackcheck, penwidth); %%���̸��еĺ�ɫ����
            Screen('FillRect', wptr, white*0.6, whitecheck, penwidth); %%���̸��еİ�ɫ����
            Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
            Screen('Flip',wptr);
            
            %%  �����������ʼ���׷��Ŀ��
            while 1
                [clicks,x,y,whichbutton]=GetClicks;
                if clicks && whichbutton==1  %�����������ѭ��
                    break;
                end
            end
            Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
            Screen('FrameRect', wptr, grey,rect, penwidth);
            Screen('FillRect', wptr, black,blackcheck, penwidth);
            Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
            Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
            Screen('FrameOval',wptr,red,InsetRect(rect1(:,1)',-mark_large,-mark_large), mark_penwidth, mark_penwidth);
            Screen('FrameOval',wptr,red,InsetRect(rect1(:,2)',-mark_large,-mark_large), mark_penwidth, mark_penwidth);
            Screen('FrameOval',wptr,red,InsetRect(rect1(:,3)',-mark_large,-mark_large), mark_penwidth, mark_penwidth);
            Screen('FrameOval',wptr,red,InsetRect(rect1(:,4)',-mark_large,-mark_large), mark_penwidth, mark_penwidth);  %%ͬʱ����ĸ�С��
            selected1(1)=1-selected1(1);
            selected1(2)=1-selected1(2);
            selected1(3)=1-selected1(3);
            selected1(4)=1-selected1(4);   %%%�����С���seleted���Ϊ1���͵���ĶԱȣ�����ȷ׷�ٵĸ���
            Screen('Flip',wptr);
            WaitSecs(0.01);
            
            %%   �����������С��ʼ�˶�
            while 1
                [clicks,x,y,whichbutton]=GetClicks;
                if clicks && whichbutton==1  %�����������ѭ��
                    break;
                end
            end
            Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
            Screen('FrameRect', wptr, grey,rect, penwidth);
            Screen('FillRect', wptr, black,blackcheck, penwidth);
            Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
            Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
            %%   ���ֲ�ͬ�������л�/���л����������ǲ��л�����
            if Matrix21(trialIndex,4)==1
                HideCursor;
                refresh=Screen('GetFlipInterval',wptr);
                refresh;
                vb1=Screen('Flip',wptr);
                starttime=GetSecs;
                time_interval=0.02;%%100hz
                while GetSecs-starttime<Matrix21(trialIndex,5)%%�л�ʱ��ǰ���˶�
                    [wd, secs, keyCode]=KbCheck;   %��esc���˳�����
                    if keyCode(quitKey)
                        Screen('CloseAll');
                        close all
                        return;
                    end
                    %% ����С��;��ο�߽����ײ
                    for i=1:size(rect5,2)    %%%С����ײ�߽�
                        rect5(:,i)=OffsetRect(rect5 (:,i)',speedxy(i,1),speedxy(i,2))';
                        rect15(:,i)=OffsetRect(rect15 (:,i)',speedxy(i,1),speedxy(i,2))';
                        if rect5(1,i)<baseRect1(1)+4 || rect5(3,i)>baseRect1(3)-4     %%С����ײ�ж�������С������ұߺͱ߿�����ұ���ײ
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,1)=-speedxy(i,1);
                        end
                        if rect5(2,i)<baseRect1(2)+4 || rect5(4,i)>baseRect1(4)-4      %%С����ײ�ж�������С������±ߺͱ߿�����±���ײ
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,2)=-speedxy(i,2);
                        end
                    end
                    
                    %%  ����С��֮����ײ
                    for i=1:size(rect5,2)-1    %% 1��С����ײ�������ٶ�
                        [x1,y1]=RectCenter(rect5(:,i)');   %%��ȡС�����������
                        sxy=speedxy(i,:);
                        for j=i+1:size(rect5,2)
                            [x2,y2]=RectCenter(rect5(:,j)');  %%��һ��С�����������
                            if sqrt((x1-x2)^2+(y1-y2)^2)<=diameter+2  %%�ж��Ƿ�С����ײ����
                                speedxy(i,:)=speedxy(j,:);
                                speedxy(j,:)=sxy;   %%С�򽻻��ٶ�
                                collisionwithothers(i)=collisionwithothers(i)+1;
                                collisionwithothers(j)=collisionwithothers(j)+1;
                            end
                        end
                    end
                    for i=1:4      %%����1���˶���12��С���ƶ������Ե�λ��
                        rect1(:,i)=rect15(:,i);
                        rect2(:,i)=rect15(:,i+4);   %%rect1��rect2��1��
                        rect4(:,i)=rect15(:,i+8);
                        rect3(:,i)=OffsetRect(rect4(:,i)',sw/2,0); %%rect3��2��
                    end
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
                    vb1=Screen('Flip',wptr,vb1+time_interval-0.5*refresh); %%����ˢ��ʱ��
                end
                
                %%  С���л���flipһ��
                Screen('Flip',wptr);
                WaitSecs(t1);
                %%  С�������ɫ����
                x = randsample(0:12,12);
                for k = 1:12
                    b = x(k);
                    color(:,k) = [b b b];
                end
                for i=1:4
                    color1(:,i) =  color(:,i);
                    color2(:,i) =  color(:,i+4);
                    color3(:,i) =  color(:,i+8);
                end
                Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                Screen('FrameRect', wptr, grey,rect, penwidth);
                Screen('FillRect', wptr, black,blackcheck, penwidth);
                Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
                Screen('Flip',wptr); %%%flip��һ��
                vb2=GetSecs;
                %%    flip֮��
                starttime=GetSecs;
                time_interval=0.02; %%100hz
                while GetSecs-starttime<duration-Matrix21(trialIndex,5)%%flip֮��С����˶�
                    [wd, secs, keyCode]=KbCheck;
                    if keyCode(quitKey)
                        Screen('CloseAll');
                        close all
                        return;
                    end
                    %% ��ײ�߽�
                    for i=1:size(rect5,2)    %%%1��С����ײ�߽�
                        rect5(:,i)=OffsetRect(rect5 (:,i)',speedxy(i,1),speedxy(i,2))';
                        rect15(:,i)=OffsetRect(rect15 (:,i)',speedxy(i,1),speedxy(i,2))';
                        if rect5(1,i)<baseRect1(1)+4 || rect5(3,i)>baseRect1(3)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,1)=-speedxy(i,1);
                        end
                        if rect5(2,i)<baseRect1(2)+4 || rect5(4,i)>baseRect1(4)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,2)=-speedxy(i,2);
                        end
                    end
                    %%  ����С��֮����ײ
                    for i=1:size(rect5,2)-1    %% 1��С����ײ�������ٶ�
                        [x1,y1]=RectCenter(rect5(:,i)');
                        sxy=speedxy(i,:);
                        for j=i+1:size(rect5,2)
                            [x2,y2]=RectCenter(rect5(:,j)');
                            if sqrt((x1-x2)^2+(y1-y2)^2)<=diameter+2
                                speedxy(i,:)=speedxy(j,:);
                                speedxy(j,:)=sxy;
                                collisionwithothers(i)=collisionwithothers(i)+1;
                                collisionwithothers(j)=collisionwithothers(j)+1;
                            end
                        end
                    end
                    
                    for i=1:4
                        rect1(:,i)=rect15(:,i);
                        rect2(:,i)=rect15(:,i+4);
                        rect4(:,i)=rect15(:,i+8);
                        rect3(:,i)=OffsetRect(rect4(:,i)',sw/2,0);
                    end
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
                    vb2=Screen('Flip',wptr,vb2+time_interval-0.5*refresh);
                end
                Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                Screen('FrameRect', wptr, grey,rect, penwidth);
                Screen('FillRect', wptr, black,blackcheck, penwidth);
                Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
                %% С���ƶ�����һ�������С��
                for i=1:4
                    rect11(:,i)=OffsetRect(rect1(:,i)',sw/2,0);%%�ҳ�����һ�����ڷֱ��Ӧ��λ��
                    rect12(:,i)=OffsetRect(rect2(:,i)',sw/2,0);
                    rect13(:,i)=OffsetRect(rect3(:,i)',-sw/2,0);
                end
                ShowCursor('Arrow',wptr); %%ʼ�ճ��ּ�ͷ
                %%    ��¼��Ӧ
                while true
                    [x,y,buttons]=GetMouse(wptr);
                    if buttons(3)
                        for i=1:size(rect1,2)
                            if selected11(i)==1 && selected1(i)==1   %%������Ŀ��ͱ��Ŀ��һ��
                                crtnumber1=crtnumber1+1;     %%��ȷ����+1����¼�ڵ�6��
                                Matrix21(trialIndex,6) = crtnumber1;
                            end
                        end
                        Screen('Flip',wptr);
                        break;
                    elseif  buttons(1)
                        %%  ���Ŀ��С����
                        for i=1:size(rect1,2)   %%���1��С����
                            if IsInRect(x,y,rect1(:,i)')
                                selected11(i)=1-selected11(i);      %%���1��.1��С����
                                Screen('FillOval',wptr,[selected11(i)*255 0 0],rect1(:,i));
                                Screen('Flip',wptr,0,1);%%����ǰ�����С��
                                break;
                            elseif IsInRect(x,y,rect11(:,i)') %%���1��.2��С����,1��ԭλ��С����ʧ
                                selected11(i)=1-selected11(i);
                                Screen('FillOval',wptr,[selected11(i)*255 0 0],rect1(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect2(:,i)')   %%���2��.2��С����
                                selected12(i)=1-selected12(i);
                                Screen('FillOval',wptr,[selected12(i)*255 0 0],rect2(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect12(:,i)')  %%���2��.1��С���죬2��ԭλ��С����ʧ
                                selected12(i)=1-selected12(i);
                                Screen('FillOval',wptr,[selected12(i)*255 0 0],rect2(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect3(:,i)')    %%���2��.2��С����
                                selected13(i)=1-selected13(i);
                                Screen('FillOval',wptr,[selected13(i)*255 0 0],rect3(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect13(:,i)')  %%���2��.1��С���죬2��ԭλ��С����ʧ
                                selected13(i)=1-selected13(i);
                                Screen('FillOval',wptr,[selected13(i)*255 0 0],rect3(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            end
                        end
                    end
                    WaitSecs(0.1);
                end
                if Matrix21(trialIndex,6) == 4      %%�����ȷ����Ϊ4��������м�Ϊ1����ʾ׷����ȷ
                    Matrix21(trialIndex,7) = 1;
                elseif Matrix21(trialIndex,6) ~= 4   %%�����ȷ����������4��������м�Ϊ2����ʾ׷�ٲ���ȷ
                    Matrix21(trialIndex,7) = 2;
                end
                
                
                %%       �л�����
            elseif  Matrix21(trialIndex,4)==2
                HideCursor;
                refresh=Screen('GetFlipInterval',wptr);
                refresh;
                vb1=Screen('Flip',wptr);
                starttime=GetSecs;
                time_interval=0.02; %%100hz
                while GetSecs-starttime<Matrix21(trialIndex,5)  %%�л�ǰС���˶�
                    [wd, secs, keyCode]=KbCheck;
                    if keyCode(quitKey)
                        Screen('CloseAll');
                        return;
                    end
                    %%  ������ײ�߽�
                    for i=1:size(rect5,2)    %%%1��С����ײ�߽�
                        rect5(:,i)=OffsetRect(rect5 (:,i)',speedxy(i,1),speedxy(i,2))';
                        rect15(:,i)=OffsetRect(rect15 (:,i)',speedxy(i,1),speedxy(i,2))';
                        if rect5(1,i)<baseRect1(1)+4 || rect5(3,i)>baseRect1(3)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,1)=-speedxy(i,1);
                        end
                        if rect5(2,i)<baseRect1(2)+4  || rect5(4,i)>baseRect1(4)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,2)=-speedxy(i,2);
                        end
                    end
                    
                    %%  ����С��֮����ײ
                    for i=1:size(rect5,2)-1    %% 1��С����ײ�������ٶ�
                        [x1,y1]=RectCenter(rect5(:,i)');
                        sxy=speedxy(i,:);
                        for j=i+1:size(rect5,2)
                            [x2,y2]=RectCenter(rect5(:,j)');
                            if sqrt((x1-x2)^2+(y1-y2)^2)<=diameter+2
                                speedxy(i,:)=speedxy(j,:);
                                speedxy(j,:)=sxy;
                                collisionwithothers(i)=collisionwithothers(i)+1;
                                collisionwithothers(j)=collisionwithothers(j)+1;
                            end
                        end
                    end
                    
                    for i=1:4
                        rect1(:,i)=rect15(:,i);
                        rect2(:,i)=rect15(:,i+4);
                        rect4(:,i)=rect15(:,i+8);
                        rect3(:,i)=OffsetRect(rect4(:,i)',sw/2,0);
                    end
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
                    vb1=Screen('Flip',wptr,vb1+time_interval-0.5*refresh);
                    
                end
                
                %%      С���л�
                Screen('Flip', wptr);  %��һ��
                WaitSecs(t1);
                %%  С�������ɫ����
                x = randsample(0:12,12);
                for k = 1:12
                    b = x(k);
                    color(:,k) = [b b b];
                end
                for i=1:4
                    color1(:,i) =  color(:,i);
                    color2(:,i) =  color(:,i+4);
                    color3(:,i) =  color(:,i+8);
                end
                for i=1:4   %%%1���л���2��С��,rect111��2��
                    rect111(:,i)=OffsetRect(rect1 (:,i)',sw/2,0)';
                end
                Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                Screen('FrameRect', wptr, grey,rect, penwidth);
                Screen('FillRect', wptr, black,blackcheck, penwidth);
                Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                Screen('FillOval',wptr,[color1,color2,color3],[rect111,rect2,rect3]);
                Screen('Flip',wptr);
                vb2=GetSecs;
                %%   �л�֮��С���˶�
                starttime=GetSecs;
                time_interval=0.02; %%100hz
                while GetSecs-starttime<duration-Matrix21(trialIndex,5)
                    [wd, secs, keyCode]=KbCheck;
                    if keyCode(quitKey)
                        Screen('CloseAll');
                        return;
                    end
                    %%    ��ײ�߽�
                    for i=1:size(rect5,2)    %%%1��С����ײ�߽�
                        rect5(:,i)=OffsetRect(rect5 (:,i)',speedxy(i,1),speedxy(i,2))';
                        rect15(:,i)=OffsetRect(rect15 (:,i)',speedxy(i,1),speedxy(i,2))';
                        if rect5(1,i)<baseRect1(1)+4 || rect5(3,i)>baseRect1(3)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,1)=-speedxy(i,1);
                        end
                        if rect5(2,i)<baseRect1(2)+4  || rect5(4,i)>baseRect1(4)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,2)=-speedxy(i,2);
                        end
                    end
                    %%  ����С��֮����ײ
                    for i=1:size(rect5,2)-1    %% 1��С����ײ�������ٶ�
                        [x1,y1]=RectCenter(rect5(:,i)');
                        sxy=speedxy(i,:);
                        for j=i+1:size(rect5,2)
                            [x2,y2]=RectCenter(rect5(:,j)');
                            if sqrt((x1-x2)^2+(y1-y2)^2)<=diameter+2
                                speedxy(i,:)=speedxy(j,:);
                                speedxy(j,:)=sxy;
                                collisionwithothers(i)=collisionwithothers(i)+1;
                                collisionwithothers(j)=collisionwithothers(j)+1;
                            end
                        end
                    end
                    
                    for i=1:size(rect1,2)
                        rect1(:,i)=rect15(:,i); %ԭʼĿ�꣬1��
                        rect111(:,i)=OffsetRect(rect1(:,i)',sw/2,0); %%�л����Ŀ�꣬2��
                        rect2(:,i)=rect15(:,i+4);
                        rect4(:,i)=rect15(:,i+8);
                        rect3(:,i)=OffsetRect(rect4(:,i)',sw/2,0);
                    end
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('FillOval',wptr,[color1,color2,color3],[rect111,rect2,rect3]);
                    vb2=Screen('Flip',wptr,vb2+time_interval-0.5*refresh);
                end
                Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                Screen('FrameRect', wptr, grey,rect, penwidth);
                Screen('FillRect', wptr, black,blackcheck, penwidth);
                Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                Screen('FillOval',wptr,[color1,color2,color3],[rect111,rect2,rect3]);
                %%  ����ĵ�
                for i=1:size(rect1,2)   %%���1��С����
                    rect21(:,i)=OffsetRect(rect111(:,i)',-sw/2,0);
                    rect22(:,i)=OffsetRect(rect2(:,i)',sw/2,0);
                    rect23(:,i)=OffsetRect(rect3(:,i)',-sw/2,0);
                end
                ShowCursor('Arrow',wptr); %%ʼ�ճ��ּ�ͷ
                %%    ��¼��Ӧ
                while true
                    [x,y,buttons]=GetMouse(wptr);
                    if buttons(3)
                        %%    ��¼��ȷ��
                        for i=1:size(rect1,2)
                            if selected21(i)==1 && selected1(i)==1
                                crtnumber1=crtnumber1+1;
                                Matrix21(trialIndex,6) = crtnumber1;
                            end
                        end
                        Screen('Flip',wptr);
                        break;
                    elseif buttons(1)
                        %%  ���Ŀ��С����
                        for i=1:size(rect1,2)   %%���1��С����
                            if IsInRect(x,y,rect111(:,i)')
                                selected21(i)=1-selected21(i);      %%���1��.1��С����
                                Screen('FillOval',wptr,[selected21(i)*255 0 0],rect111(:,i));
                                Screen('Flip',wptr,0,1);%%����ǰ�����С��
                                break;
                            elseif IsInRect(x,y,rect21(:,i)')   %%���1��.2��С����,1��ԭλ��С����ʧ
                                selected21(i)=1-selected21(i);
                                Screen('FillOval',wptr,[selected21(i)*255 0 0],rect111(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect2(:,i)') %%���2��.2��С����
                                selected22(i)=1-selected22(i);
                                Screen('FillOval',wptr,[selected22(i)*255 0 0],rect2(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect22(:,i)')   %%���2��.1��С���죬2��ԭλ��С����ʧ
                                selected22(i)=1-selected22(i);
                                Screen('FillOval',wptr,[selected22(i)*255 0 0],rect2(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect3(:,i)')    %%���2��.2��С����
                                selected23(i)=1-selected23(i);
                                Screen('FillOval',wptr,[selected23(i)*255 0 0],rect3(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect23(:,i)')  %%���2��.1��С���죬2��ԭλ��С����ʧ
                                selected23(i)=1-selected23(i);
                                Screen('FillOval',wptr,[selected23(i)*255 0 0],rect3(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            end
                        end
                    end
                    WaitSecs(0.1);
                end
                if Matrix21(trialIndex,6) == 4
                    Matrix21(trialIndex,7) = 1;
                elseif Matrix21(trialIndex,6) ~= 4
                    Matrix21(trialIndex,7) = 2;
                end
            end
            ShowCursor('Arrow',wptr); %%ʼ�ճ��ּ�ͷ
            
            
            %%   Ŀ����������
        elseif  Matrix21(trialIndex,3)==2
            %%  С�������ɫ����
            x = randsample(0:12,12);
            for k = 1:12
                b = x(k);
                color(:,k) = [b b b];
            end
            for i=1:4
                color1(:,i) =  color(:,i);
                color2(:,i) =  color(:,i+4);
                color3(:,i) =  color(:,i+8);
            end
            %%  С�����λ�ã�ǰ4��С����Ŀ����2�򣬼�2����8����rect1��Ŀ�꣬rect3�Ǹ����rect2��1���Ǹ�����
            for i=1:4
                rect8(:,i)=rect15(:,i);
                rect1(:,i)=OffsetRect(rect8(:,i)',sw/2,0);  %5rect1��Ŀ�꣬2��
                rect2(:,i)=rect15(:,i+4);    %%rect2��1���Ǹ�����
                rect4(:,i)=rect15(:,i+8);
                rect3(:,i)=OffsetRect(rect4(:,i)',sw/2,0);  %%rect3�Ǹ����2��
            end
            Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
            Screen('FrameRect', wptr, grey,rect, penwidth);
            Screen('FillRect', wptr, black,blackcheck, penwidth);
            Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
            Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2, rect3]);
            Screen('Flip',wptr);
            
            %%  �����������ʼ���׷��Ŀ��
            while 1
                [clicks,x,y,whichbutton]=GetClicks;
                if clicks && whichbutton==1  %�����������ѭ��
                    break;
                end
            end
            Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
            Screen('FrameRect', wptr, grey,rect, penwidth);
            Screen('FillRect', wptr, black,blackcheck, penwidth);
            Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
            Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2, rect3]);
            Screen('FrameOval',wptr,red,InsetRect(rect1(:,1)',-mark_large,-mark_large), mark_penwidth, mark_penwidth);
            Screen('FrameOval',wptr,red,InsetRect(rect1(:,2)',-mark_large,-mark_large), mark_penwidth, mark_penwidth);
            Screen('FrameOval',wptr,red,InsetRect(rect1(:,3)',-mark_large,-mark_large), mark_penwidth, mark_penwidth);
            Screen('FrameOval',wptr,red,InsetRect(rect1(:,4)',-mark_large,-mark_large), mark_penwidth, mark_penwidth);
            selected1(1)=1-selected1(1);
            selected1(2)=1-selected1(2);
            selected1(3)=1-selected1(3);
            selected1(4)=1-selected1(4);
            Screen('Flip',wptr);
            %             WaitSecs(0.01);
            
            %%   �����������С��ʼ�˶�
            while 1
                [clicks,x,y,whichbutton]=GetClicks;
                if clicks && whichbutton==1  %�����������ѭ��
                    break;
                end
            end
            Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
            Screen('FrameRect', wptr, grey,rect, penwidth);
            Screen('FillRect', wptr, black,blackcheck, penwidth);
            Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
            Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
            %% ���ֲ�ͬ�������л�/���л����������ǲ��л�����
            if Matrix21(trialIndex,4)==1
                HideCursor;
                refresh=Screen('GetFlipInterval',wptr);
                refresh;
                vb1=Screen('Flip',wptr);
                starttime=GetSecs;
                time_interval=0.02; %%100hz
                while GetSecs-starttime<Matrix21(trialIndex,5)%%�л�ʱ��ǰ���˶�
                    [wd, secs, keyCode]=KbCheck;
                    if keyCode(quitKey)
                        Screen('CloseAll');
                        close all
                        return;
                    end
                    %% ����С��;��ο�߽����ײ
                    for i=1:size(rect5,2)    %%%С����ײ�߽�
                        rect5(:,i)=OffsetRect(rect5 (:,i)',speedxy(i,1),speedxy(i,2))';
                        rect15(:,i)=OffsetRect(rect15 (:,i)',speedxy(i,1),speedxy(i,2))';
                        if rect5(1,i)<baseRect1(1)+4 || rect5(3,i)>baseRect1(3)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,1)=-speedxy(i,1);
                        end
                        if rect5(2,i)<baseRect1(2)+4 || rect5(4,i)>baseRect1(4)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,2)=-speedxy(i,2);
                        end
                    end
                    
                    %%  ����С��֮����ײ
                    for i=1:size(rect5,2)-1    %% 1��С����ײ�������ٶ�
                        [x1,y1]=RectCenter(rect5(:,i)');
                        sxy=speedxy(i,:);
                        for j=i+1:size(rect5,2)
                            [x2,y2]=RectCenter(rect5(:,j)');
                            if sqrt((x1-x2)^2+(y1-y2)^2)<=diameter+2
                                speedxy(i,:)=speedxy(j,:);
                                speedxy(j,:)=sxy;
                                collisionwithothers(i)=collisionwithothers(i)+1;
                                collisionwithothers(j)=collisionwithothers(j)+1;
                            end
                        end
                    end
                    for i=1:4
                        rect8(:,i)=rect15(:,i);
                        rect1(:,i)=OffsetRect(rect8(:,i)',sw/2,0);
                        rect2(:,i)=rect15(:,i+4);
                        rect4(:,i)=rect15(:,i+8);
                        rect3(:,i)=OffsetRect(rect4(:,i)',sw/2,0);
                    end
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
                    vb1=Screen('Flip',wptr,vb1+time_interval-0.5*refresh);
                end
                
                %%  С���л���flipһ��
                Screen('Flip',wptr);
                WaitSecs(t1);
                %%  С�������ɫ����
                x = randsample(0:12,12);
                for k = 1:12
                    b = x(k);
                    color(:,k) = [b b b];
                end
                for i=1:4
                    color1(:,i) =  color(:,i);
                    color2(:,i) =  color(:,i+4);
                    color3(:,i) =  color(:,i+8);
                end
                Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                Screen('FrameRect', wptr, grey,rect, penwidth);
                Screen('FillRect', wptr, black,blackcheck, penwidth);
                Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
                Screen('Flip',wptr); %%%flip��һ��
                vb2=GetSecs;
                %%    flip֮��
                starttime=GetSecs;
                %                 time_interval=0.02; %%60hz
                time_interval=0.02; %%100hz
                while GetSecs-starttime<duration-Matrix21(trialIndex,5)%%flip֮��С����˶�
                    [wd, secs, keyCode]=KbCheck;
                    if keyCode(quitKey)
                        Screen('CloseAll');
                        close all
                        return;
                    end
                    %% ��ײ�߽�
                    for i=1:size(rect5,2)    %%%1��С����ײ�߽�
                        rect5(:,i)=OffsetRect(rect5 (:,i)',speedxy(i,1),speedxy(i,2))';
                        rect15(:,i)=OffsetRect(rect15 (:,i)',speedxy(i,1),speedxy(i,2))';
                        if rect5(1,i)<baseRect1(1)+4 || rect5(3,i)>baseRect1(3)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,1)=-speedxy(i,1);
                        end
                        if rect5(2,i)<baseRect1(2)+4 || rect5(4,i)>baseRect1(4)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,2)=-speedxy(i,2);
                        end
                    end
                    %%  ����С��֮����ײ
                    for i=1:size(rect5,2)-1    %% 1��С����ײ�������ٶ�
                        [x1,y1]=RectCenter(rect5(:,i)');
                        sxy=speedxy(i,:);
                        for j=i+1:size(rect5,2)
                            [x2,y2]=RectCenter(rect5(:,j)');
                            if sqrt((x1-x2)^2+(y1-y2)^2)<=diameter+2
                                speedxy(i,:)=speedxy(j,:);
                                speedxy(j,:)=sxy;
                                collisionwithothers(i)=collisionwithothers(i)+1;
                                collisionwithothers(j)=collisionwithothers(j)+1;
                            end
                        end
                    end
                    
                    for i=1:4
                        rect8(:,i)=rect15(:,i);
                        rect1(:,i)=OffsetRect(rect8(:,i)',sw/2,0);
                        rect2(:,i)=rect15(:,i+4);
                        rect4(:,i)=rect15(:,i+8);
                        rect3(:,i)=OffsetRect(rect4(:,i)',sw/2,0);
                    end
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
                    vb2=Screen('Flip',wptr,vb2+time_interval-0.5*refresh);
                end
                Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                Screen('FrameRect', wptr, grey,rect, penwidth);
                Screen('FillRect', wptr, black,blackcheck, penwidth);
                Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
                
                %% ���С���ƶ�����һ�������С��
                for i=1:4   %%��ǰС������һ��������Ӧ��С��λ��
                    rect11(:,i)=OffsetRect(rect1(:,i)',-sw/2,0);
                    rect12(:,i)=OffsetRect(rect2(:,i)',sw/2,0);
                    rect13(:,i)=OffsetRect(rect3(:,i)',-sw/2,0);
                end
                ShowCursor('Arrow',wptr); %%ʼ�ճ��ּ�ͷ
                %%    ��¼��Ӧ
                while true
                    [x,y,buttons]=GetMouse(wptr);
                    if buttons(3)
                        %%    ��¼��ȷ��
                        for i=1:size(rect1,2)
                            if selected11(i)==1 && selected1(i)==1
                                crtnumber1=crtnumber1+1;
                                Matrix21(trialIndex,6) = crtnumber1;
                            end
                        end
                        Screen('Flip',wptr);
                        break;
                    elseif buttons(1)
                        %%  ���Ŀ��С����
                        for i=1:size(rect1,2)  %%���1��С����
                            if IsInRect(x,y,rect1(:,i)')
                                selected11(i)=1-selected11(i);      %%���1��.1��С����
                                Screen('FillOval',wptr,[selected11(i)*255 0 0],rect1(:,i));
                                Screen('Flip',wptr,0,1);%%����ǰ�����С��
                                break;
                            elseif IsInRect(x,y,rect11(:,i)')  %%���1��.2��С����,1��ԭλ��С����ʧ
                                selected11(i)=1-selected11(i);
                                Screen('FillOval',wptr,[selected11(i)*255 0 0],rect1(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect2(:,i)')   %%���2��.2��С����
                                selected12(i)=1-selected12(i);
                                Screen('FillOval',wptr,[selected12(i)*255 0 0],rect2(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect12(:,i)')   %%���2��.1��С���죬2��ԭλ��С����ʧ
                                selected12(i)=1-selected12(i);
                                Screen('FillOval',wptr,[selected12(i)*255 0 0],rect2(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect3(:,i)') %%���2��.2��С����
                                selected13(i)=1-selected13(i);
                                Screen('FillOval',wptr,[selected13(i)*255 0 0],rect3(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect13(:,i)')  %%���2��.1��С���죬2��ԭλ��С����ʧ
                                selected13(i)=1-selected13(i);
                                Screen('FillOval',wptr,[selected13(i)*255 0 0],rect3(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            end
                        end
                    end
                    WaitSecs(0.1);
                end
                if Matrix21(trialIndex,6) == 4
                    Matrix21(trialIndex,7) = 1;
                elseif Matrix21(trialIndex,6) ~= 4
                    Matrix21(trialIndex,7) = 2;
                end
                %%    �����л�����
            elseif  Matrix21(trialIndex,4)==2
                HideCursor;
                refresh=Screen('GetFlipInterval',wptr);
                refresh;
                vb1=Screen('Flip',wptr);
                starttime=GetSecs;
                %                 time_interval=0.02; %%60hz
                time_interval=0.02; %%100hz
                while GetSecs-starttime<Matrix21(trialIndex,5)  %%�л�ǰС���˶�
                    [wd, secs, keyCode]=KbCheck;
                    if keyCode(quitKey)
                        Screen('CloseAll');
                        return;
                    end
                    %%  ������ײ�߽�
                    for i=1:size(rect5,2)    %%%1��С����ײ�߽�
                        rect5(:,i)=OffsetRect(rect5 (:,i)',speedxy(i,1),speedxy(i,2))';
                        rect15(:,i)=OffsetRect(rect15 (:,i)',speedxy(i,1),speedxy(i,2))';
                        if rect5(1,i)<baseRect1(1)+4 || rect5(3,i)>baseRect1(3)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,1)=-speedxy(i,1);
                        end
                        if rect5(2,i)<baseRect1(2)+4  || rect5(4,i)>baseRect1(4)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,2)=-speedxy(i,2);
                        end
                    end
                    
                    %%  ����С��֮����ײ
                    for i=1:size(rect5,2)-1    %% 1��С����ײ�������ٶ�
                        [x1,y1]=RectCenter(rect5(:,i)');
                        sxy=speedxy(i,:);
                        for j=i+1:size(rect5,2)
                            [x2,y2]=RectCenter(rect5(:,j)');
                            if sqrt((x1-x2)^2+(y1-y2)^2)<=diameter+2
                                speedxy(i,:)=speedxy(j,:);
                                speedxy(j,:)=sxy;
                                collisionwithothers(i)=collisionwithothers(i)+1;
                                collisionwithothers(j)=collisionwithothers(j)+1;
                            end
                        end
                    end
                    
                    for i=1:4
                        rect8(:,i)=rect15(:,i);
                        rect1(:,i)=OffsetRect(rect8(:,i)',sw/2,0);
                        rect2(:,i)=rect15(:,i+4);
                        rect4(:,i)=rect15(:,i+8);
                        rect3(:,i)=OffsetRect(rect4(:,i)',sw/2,0);
                    end
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('FillOval',wptr,[color1,color2,color3],[rect1,rect2,rect3]);
                    vb1=Screen('Flip',wptr,vb1+time_interval-0.5*refresh);
                end
                
                %%      С���л�
                Screen('Flip', wptr);  %��һ��
                WaitSecs(t1);
                %%  С�������ɫ����
                x = randsample(0:12,12);
                for k = 1:12
                    b = x(k);
                    color(:,k) = [b b b];
                end
                for i=1:4
                    color1(:,i) =  color(:,i);
                    color2(:,i) =  color(:,i+4);
                    color3(:,i) =  color(:,i+8);
                end
                for i=1:4   %%%2���л���1��С��,rect111��1��
                    rect111(:,i)=OffsetRect(rect1 (:,i)',-sw/2,0)';
                end
                Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                Screen('FrameRect', wptr, grey,rect, penwidth);
                Screen('FillRect', wptr, black,blackcheck, penwidth);
                Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                Screen('FillOval',wptr,[color1,color2,color3],[rect111,rect2,rect3]);
                Screen('Flip',wptr);
                vb2=GetSecs;
                %%   �л�֮��С���˶�
                starttime=GetSecs;
                time_interval=0.02; %%100hz
                while GetSecs-starttime<duration-Matrix21(trialIndex,5)
                    [wd, secs, keyCode]=KbCheck;
                    if keyCode(quitKey)
                        Screen('CloseAll');
                        return;
                    end
                    %%    ��ײ�߽�
                    for i=1:size(rect5,2)    %%%1��С����ײ�߽�
                        rect5(:,i)=OffsetRect(rect5 (:,i)',speedxy(i,1),speedxy(i,2))';
                        rect15(:,i)=OffsetRect(rect15 (:,i)',speedxy(i,1),speedxy(i,2))';
                        if rect5(1,i)<baseRect1(1)+4 || rect5(3,i)>baseRect1(3)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,1)=-speedxy(i,1);
                        end
                        if rect5(2,i)<baseRect1(2)+4  || rect5(4,i)>baseRect1(4)-4
                            collisionwithborder(i)=collisionwithborder(i)+1;
                            speedxy(i,2)=-speedxy(i,2);
                        end
                    end
                    %%  ����С��֮����ײ
                    for i=1:size(rect5,2)-1    %% 1��С����ײ�������ٶ�
                        [x1,y1]=RectCenter(rect5(:,i)');
                        sxy=speedxy(i,:);
                        for j=i+1:size(rect5,2)
                            [x2,y2]=RectCenter(rect5(:,j)');
                            if sqrt((x1-x2)^2+(y1-y2)^2)<=diameter+2
                                speedxy(i,:)=speedxy(j,:);
                                speedxy(j,:)=sxy;
                                collisionwithothers(i)=collisionwithothers(i)+1;
                                collisionwithothers(j)=collisionwithothers(j)+1;
                            end
                        end
                    end
                    for i=1:4
                        rect111(:,i)=rect15(:,i);
                        rect2(:,i)=rect15(:,i+4);
                        rect4(:,i)=rect15(:,i+8);
                        rect3(:,i)=OffsetRect(rect4(:,i)',sw/2,0);
                    end
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('FillOval',wptr,[color1,color2,color3],[rect111,rect2,rect3]);
                    vb2=Screen('Flip',wptr,vb2+time_interval-0.5*refresh);
                end
                Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                Screen('FrameRect', wptr, grey,rect, penwidth);
                Screen('FillRect', wptr, black,blackcheck, penwidth);
                Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                Screen('FillOval',wptr,[color1,color2,color3],[rect111,rect2,rect3]);
                %% ���С���ƶ�����һ�������С��
                for i=1:size(rect1,2)   %%���1��С����
                    rect21(:,i)=OffsetRect(rect111(:,i)',sw/2,0);
                    rect22(:,i)=OffsetRect(rect2(:,i)',sw/2,0);
                    rect23(:,i)=OffsetRect(rect3(:,i)',-sw/2,0);
                end
                ShowCursor('Arrow',wptr); %%ʼ�ճ��ּ�ͷ
                %%    ��¼��Ӧ
                while true
                    [x,y,buttons]=GetMouse(wptr);
                    if buttons(3)
                        %%    ��¼��ȷ��
                        for i=1:size(rect1,2)
                            if selected21(i)==1 && selected1(i)==1
                                crtnumber1=crtnumber1+1;
                                Matrix21(trialIndex,6) = crtnumber1;
                            end
                        end
                        Screen('Flip',wptr);
                        break;
                    elseif buttons(1)
                        %%  ���Ŀ��С����
                        for i=1:size(rect1,2)   %%���1��С����
                            if IsInRect(x,y,rect111(:,i)')
                                selected21(i)=1-selected21(i);      %%���1��.1��С����
                                Screen('FillOval',wptr,[selected21(i)*255 0 0],rect111(:,i));
                                Screen('Flip',wptr,0,1);%%����ǰ�����С��
                                break;
                            elseif IsInRect(x,y,rect21(:,i)') %%���1��.2��С����,1��ԭλ��С����ʧ
                                selected21(i)=1-selected21(i);
                                Screen('FillOval',wptr,[selected21(i)*255 0 0],rect111(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect2(:,i)')  %%���2��.2��С����
                                selected22(i)=1-selected22(i);
                                Screen('FillOval',wptr,[selected22(i)*255 0 0],rect2(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect22(:,i)')    %%���2��.1��С���죬2��ԭλ��С����ʧ
                                selected22(i)=1-selected22(i);
                                Screen('FillOval',wptr,[selected22(i)*255 0 0],rect2(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect3(:,i)')  %%���2��.2��С����
                                selected23(i)=1-selected23(i);
                                Screen('FillOval',wptr,[selected23(i)*255 0 0],rect3(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            elseif IsInRect(x,y,rect23(:,i)')   %%���2��.1��С���죬2��ԭλ��С����ʧ
                                selected23(i)=1-selected23(i);
                                Screen('FillOval',wptr,[selected23(i)*255 0 0],rect3(:,i));
                                Screen('Flip',wptr,0,1);
                                break;
                            end
                        end
                    end
                    WaitSecs(0.1);
                end
                if Matrix21(trialIndex,6) == 4
                    Matrix21(trialIndex,7) = 1;
                elseif Matrix21(trialIndex,6) ~= 4
                    Matrix21(trialIndex,7) = 2;
                end
            end
        end
        ShowCursor('Arrow',wptr); %%ʼ�ճ��ּ�ͷ
        %%   ������
        while true
            [x,y,buttons]=GetMouse(wptr);
            if buttons(3)
                if trialIndex==20 %�������Ҽ�������һtrail
                    %                 if trialIndex==2 %�������Ҽ�������һtrail
                    Screen('Flip',wptr);
                    overtext = sprintf('Have A Rest1!!!');
                    DrawFormattedText(wptr, overtext, xCenter_left,yCenter,black);
                    DrawFormattedText(wptr, overtext,xCenter_right,yCenter,black);
                    Screen('Flip',wptr);
                    WaitSecs(2);
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('FillRect', wptr, black,cross, penwidth);%%����ʮ�ּ�
                    Screen('Flip',wptr);
                    break;
                elseif trialIndex==40 %�������Ҽ�������һtrail
                    Screen('Flip',wptr);
                    overtext = sprintf('Have A Rest2!!!');
                    DrawFormattedText(wptr, overtext, xCenter_left,yCenter,black);
                    DrawFormattedText(wptr, overtext,xCenter_right,yCenter,black);
                    Screen('Flip',wptr);
                    WaitSecs(2);
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('FillRect', wptr, black,cross, penwidth);%%����ʮ�ּ�
                    Screen('Flip',wptr);
                    break;
                elseif trialIndex==60 %�������Ҽ�������һtrail
                    Screen('Flip',wptr);
                    overtext = sprintf('Have A Rest3!!!');
                    DrawFormattedText(wptr, overtext, xCenter_left,yCenter,black);
                    DrawFormattedText(wptr, overtext,xCenter_right,yCenter,black);
                    Screen('Flip',wptr);
                    WaitSecs(2);
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('FillRect', wptr, black,cross, penwidth);%%����ʮ�ּ�
                    Screen('Flip',wptr);
                    break;
                elseif trialIndex==80 %�������Ҽ�������һtrail
                    Screen('Flip',wptr);
                    overtext = sprintf('Have A Rest4!!!');
                    DrawFormattedText(wptr, overtext, xCenter_left,yCenter,black);
                    DrawFormattedText(wptr, overtext,xCenter_right,yCenter,black);
                    Screen('Flip',wptr);
                    WaitSecs(2);
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('FillRect', wptr, black,cross, penwidth);%%����ʮ�ּ�
                    Screen('Flip',wptr);
                    break;
                elseif trialIndex==100 %�������Ҽ�������һtrail
                    Screen('Flip',wptr);
                    overtext = sprintf('Have A Rest5!!!');
                    DrawFormattedText(wptr, overtext, xCenter_left,yCenter,black);
                    DrawFormattedText(wptr, overtext,xCenter_right,yCenter,black);
                    Screen('Flip',wptr);
                    WaitSecs(2);
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('FillRect', wptr, black,cross, penwidth);%%����ʮ�ּ�
                    Screen('Flip',wptr);
                    break;
                elseif trialIndex==length(Matrix21)
                    %                 elseif trialIndex==2
                    Screen('Flip',wptr);
                    overtext = sprintf('Over! Thank You!!');
                    DrawFormattedText(wptr, overtext, xCenter_left,yCenter,black);
                    DrawFormattedText(wptr, overtext,xCenter_right,yCenter,black);
                    Screen('Flip',wptr);
                    WaitSecs(2);
                    break;
                else
                    Screen('Flip',wptr);
                    Screen('DrawLines', wptr,xys, griddpenwidth,white*0.6);
                    Screen('FrameRect', wptr, grey,rect, penwidth);
                    Screen('FillRect', wptr, black,blackcheck, penwidth);
                    Screen('FillRect', wptr, white*0.6, whitecheck, penwidth);
                    Screen('Flip',wptr);
                    WaitSecs(0.01);
                    break;
                end
            end
        end
    end
    save(fileName,'Matrix21');    %%%��������
catch ME
    display(sprintf('Error in Experiment. Please get experimenter.'));
    Priority(0);
    ShowCursor;
    ListenChar(0);
    Screen('CloseAll');
end
Screen('CloseAll');
