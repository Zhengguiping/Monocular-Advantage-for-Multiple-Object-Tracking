function pixs = deg2pix(degree,inch ,pwidth,vdist)%degree度数；inch显示器大小，英寸；pwidth，像素尺寸；vdist，观察距离�?
screenWidth = 53;
pwidth = 1920;
pix=screenWidth/pwidth;
pixs = round(2*tan((degree/2)*pi/180)*vdist/pix);
return;