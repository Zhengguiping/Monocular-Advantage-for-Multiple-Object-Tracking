%%  批量分析，正确率=追踪正确个数/总个数
clear all;
close all;
clc;
filepath ='E:\MOT课题\AA_MOT\MOTexpmain_data\MOTexpmain\MOTexp - 副本\expmain1\data\';
numeber = 19;
ACC = zeros(numeber,6);
for j = 1:numeber
    load([filepath  'S' num2str(j) '.mat']); %%加载全部mat数据
    a11=0;a12=0;a21=0;a22=0;
    b11=0;b12=0;b21=0;b22=0;
    c11=0;c12=0;c21=0;c22=0;

    T=20*4;  %%需要追踪的总个数；   20：Trial数
    
    for i= 1:length(Matrix21)
        if Matrix21(i,2)==1    %%速度为1
            if Matrix21(i,4)==1 %不切换
                a11=Matrix21(i,6); %% 追踪正确个数
                a12=a11+a12;   %%速度2不切换条件
            elseif Matrix21(i,4)==2 %切换
                a21 = Matrix21(i,6); %% 追踪正确个数
                a22=a21+a22; %%速度2切切换条件
            end
        elseif Matrix21(i,2)==2    %%速度为2
            if Matrix21(i,4)==1 %不切换
                b11 = Matrix21(i,6); %% 追踪正确个数
                b12=b11+b12;%%速度4不切换条件
            elseif Matrix21(i,4)==2   %%切换
                b21 =Matrix21(i,6); %% 追踪正确个数
                b22=b21+b22;%%速度4切换条件
            end
          elseif Matrix21(i,2)==3    %%速度为3
            if Matrix21(i,4)==1 %不切换
                c11 = Matrix21(i,6); %% 追踪正确个数
                c12=c11+c12;%%速度4不切换条件
            elseif Matrix21(i,4)==2   %%切换
                c21 =Matrix21(i,6); %% 追踪正确个数
                c22=c21+c22;%%速度4切换条件
            end
        end
        
    end
    
    %%速度1
    ACC(j,1)=a12/T;%速度1不切换条件正确率
    ACC(j,2)=a22/T;%速度1切换正确率
    %%速度2
    ACC(j,3)=b12/T;%%速度2不切换条件正确率
    ACC(j,4)=b22/T;%%速度2切换正确率
     %%速度3
    ACC(j,5)=c12/T;%%速度3不切换条件正确率
    ACC(j,6)=c22/T;%%速度3切换正确率
end
